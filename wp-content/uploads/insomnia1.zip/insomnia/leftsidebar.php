<div id="sidebar">

<div id="colTwo">



<ul>
<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(2) ) : else : ?>

 <h2>
   <label for="s"><?php _e('Search:'); ?></label></h2>
   <form id="searchform" method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">
	<div>
		<input type="text" name="s" id="s" size="15" />
		<input type="submit" value="<?php _e('Go!'); ?>" />
	</div>
	</form>
<br/>
 

<h2><?php _e('Meta:'); ?></h2>
 	<ul>
		<?php wp_register(); ?>
		<li><?php wp_loginout(); ?></li>
   <li><a href="http://www.headsetoptions.org/folio" title="WP Web Design">Web Design</a></li>
<li><a href="http://www.mandarinmusing.com/themes" title="New WP Themes">New WP Themes</a></li> 
<li><a href="http://www.wpsnap.com" title="The Very Best of WordPress">WP Resources</a></li>
<li><a href="http://www.dirsnap.com" title="World Wide Web Directory">Web Resources</a></li>

		
		<li><a href="http://gmpg.org/xfn/"><abbr title="XHTML Friends Network">XFN</abbr></a></li>
		<li><a href="http://www.browse8.com" title="Free Themes">Free Themes</a> <a href="http://televisie.jahier.nl" title="Televisie">Televisie</a></li>
		
		<?php wp_meta(); ?>
	</ul>
 <br/>


<h2>Flickr:</h2>
<div id="flickr">
<script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=4&amp;display=random&amp;size=s&amp;layout=x&amp;source=all_tag&amp;tag=art"></script>
</div>	
<br/>




<?php endif; ?>
</ul>



</div>


</div>



