<!-- begin footer -->

<!-- Do not deleting the credits, 

This theme is released for free under a dual license. The CSS (stylesheet) and images of this theme are released under a <a href="http://creativecommons.org/licenses/by/2.5/">Creative Commons Attribution 2.5 License</a>, while the rest of the theme files are released under a <a href="http://www.gnu.org/licenses/gpl.html">GNU GPL License</a>. 

If you use our themes, it will be assumed that you have read and accepted the following terms and conditions, included in the License Document. 
  	
You may get the designer links removed for a small fee by contacting us. Failing to do so is illegal. Pls read the License Document, included in the Zip File of this theme for "Terms and conditions".

I'd appreciate the designer credits being left in unmodified, thanks in advance. Feel free to contact us at Headsetoptions.org for theme support, theme customization, premium templates, suggestions, or other queries, etc. Thanks for your interest, and happy blogging! -->



<!-- Footer -->

<div id="footer" class="fixed"> Copyright &copy; <?php bloginfo('name'); ?> | <a
href="http://www.freecsstemplates.org/">Insomnia</a> by <a href="http://www.headsetoptions.org/">Headsetoptions</a> + <a href="http://www.mandarinmusing.com" title="Theme Ported to WordPress by MandarinMusing">MandarinMusing</a> | supported by <a href="http://www.browse8.com" title="Free Themes">Free Themes</a> <a href="http://televisie.jahier.nl" title="Televisie">Televisie</a>

</div>

<!-- End Footer -->



<?php wp_footer(); ?>

<!--Counter-->

<!--END Counter-->

</body>
</html>