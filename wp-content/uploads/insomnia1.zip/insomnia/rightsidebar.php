<div id="sidebar">

<div id="colThree">


<ul>
<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(1) ) : else : ?>

<?php global $notfound; ?>
 <?php /* Creates a menu for pages beneath the level of the current page */
  if (is_page() and ($notfound != '1')) {
   $current_page = $post->ID;
   while($current_page) {
    $page_query = $wpdb->get_row("SELECT ID, post_title, post_status, post_parent FROM $wpdb->posts WHERE ID = '$current_page'");
    $current_page = $page_query->post_parent;
   }
   $parent_id = $page_query->ID;
   $parent_title = $page_query->post_title;
 
   if ($wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_parent = '$parent_id' AND post_status != 'attachment'")) { ?>
 
   <div class="sb-pagemenu"><h2><?php _e('Subpages:'); ?></h2>
    <ul>
     <?php wp_list_pages('sort_column=menu_order&title_li=&child_of='. $parent_id); ?>
    </ul>
	<br/><br/>
   
    <?php if ($parent_id != $post->ID) { ?>
     <a href="<?php echo get_permalink($parent_id); ?>"><?php printf(__('Back to %s'), $parent_title ) ?></a>
    <?php } ?>
   </div>
 <?php } } ?>
 
 <?php if (is_attachment()) { ?>
  <div class="sb-pagemenu">
   <a href="<?php echo get_permalink($post->post_parent); ?>" rev="attachment"><?php printf(__('Back to \'%s\''), get_the_title($post->post_parent) ) ?></a>
  </div>
 <?php } ?>




<h2><?php _e('Categories:'); ?></h2>
<ul><?php wp_list_cats(); ?></ul>
<br/>
 

<h2><?php _e('Archives:'); ?></h2>
<ul><?php wp_get_archives('type=monthly'); ?></ul>
<br/>


<?php endif; ?>
</ul>



</div>

</div>



