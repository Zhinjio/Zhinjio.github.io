<!-- begin footer -->

<!-- Do not delete the credits, 
This theme is released for free under the GNU General Public License (GPL) requiring that the credits will stay intact.
I'd appreciate the credit being left in unmodified, thanks in advance -->

<div style="clear: both; height: 1px;"></div>
</div>

<!-- end #page -->
<div id="footer">
<p id="legal">Copyright &copy; <?php bloginfo('name'); ?> | <a href="<?php bloginfo('siteurl')?>/wp-admin/" title="login">WordPress</a> using <a href="http://www.freecsstemplates.org">Deserted</a> <a href="http://www.wpsnap.com" title="The Very Best of WordPress">3</a><a href="http://www.dirsnap.com" title="World Wide Web Directory">C</a> by <a href="http://www.headsetoptions.org">Headsetoptions</a> + <a href="http://www.mandarinmusing.com/"> MandarinMusing</a> | Supported by <a href="http://www.americanfibersystems.com">Broadband Provider</a> + <a href="http://charlotte.neboweb.com">Charlotte Web Design</a></p>
</div>

<?php wp_footer(); ?>
</body>
</html>
