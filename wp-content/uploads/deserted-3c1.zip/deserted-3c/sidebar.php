<div id="sidebar">



<div id="menu">
<h2>Navigation Menu</h2>
<ul>
<li><a href="<?php echo get_settings('home'); ?>/">Home</a></li><?php wp_list_pages('sort_column=menu_order&depth=1&title_li='); ?>
</ul>
</div>
<!-- end #menu -->
		

<!-- Left Sidebar -->

<div class="sidebar_left">

<?php global $notfound; ?>
 <?php /* Creates a menu for pages beneath the level of the current page */
  if (is_page() and ($notfound != '1')) {
   $current_page = $post->ID;
   while($current_page) {
    $page_query = $wpdb->get_row("SELECT ID, post_title, post_status, post_parent FROM $wpdb->posts WHERE ID = '$current_page'");
    $current_page = $page_query->post_parent;
   }
   $parent_id = $page_query->ID;
   $parent_title = $page_query->post_title;
 

if ($wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_parent = '$parent_id' AND post_status != 'attachment'")) { ?>


<div class="sb-pagemenu">

<h2><?php _e('Subpages:'); ?></h2>
				
     <ul><?php wp_list_pages('sort_column=menu_order&title_li=&child_of='. $parent_id); ?></ul>
   
    <?php if ($parent_id != $post->ID) { ?>
     <a href="<?php echo get_permalink($parent_id); ?>"><?php printf(__('Back to %s'), $parent_title ) ?></a>
    <?php } ?>
   </div>
<br/><br/>
 <?php } } ?>
 
 <?php if (is_attachment()) { ?>
  <div class="sb-pagemenu">
   <a href="<?php echo get_permalink($post->post_parent); ?>" rev="attachment"><?php printf(__('Back to \'%s\''), get_the_title($post->post_parent) ) ?></a>
  </div>
<br/><br/>
 <?php } ?>


<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(1) ) : else : ?>

<h2><?php _e('Search:'); ?> </h2>
<form id="searchform" method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<input type="text" name="s" id="s" size="11" /> <input type="submit" value="<?php _e('Go!'); ?>"/>
</form>

<br/>


<h2><?php _e('Categories:'); ?> </h2>
<ul>
<?php wp_list_cats(); ?>
</ul>
<br/>

<h2><?php _e('Archives:'); ?> </h2>
<ul>
<?php wp_get_archives('type=monthly'); ?>
</ul>
<br/>

<h2><?php _e('Meta:'); ?> </h2>
<ul class="sidemenu">
<?php wp_register(); ?>
<li><?php wp_loginout(); ?></li>
<li><a href="http://www.headsetoptions.org/folio" title="Web Design">Design Services</a></li>
<li><a href="http://www.mandarinmusing.com/themes" title="WP Themes">WP Themes</a></li>
<li><a href="http://www.wpsnap.com" title="The Very Best of WordPress">Best of WP</a></li>
<li><a href="http://www.dirsnap.com" title="World Wide Web Directory">Web Resources</a></li>
<?php wp_meta(); ?>
</ul>
<br/>

<?php endif; ?>	

</div>

<!-- End Left Sidebar -->


<!-- Right Sidebar -->

<div class="sidebar_right">

<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(2) ) : else : ?>
  
<a href="<?php bloginfo('rss2_url'); ?>"><img src="http://i71.photobucket.com/albums/i136/headsetop/RSS1.gif" alt="rss feed" /></a>

<a href="http://technorati.com/faves?add=<?php bloginfo('siteurl'); ?>"><img src="http://i71.photobucket.com/albums/i136/headsetop/technorati.gif" alt="technorati fav" /></a>   


<h2><?php _e('Advertise:'); ?> </h2>

<!-- Dummy Ad -->
<a href="http://www.wpsnap.com/"><img src="https://www.google.com/adsense/static/en_US/images/skyscraper_img.jpg" alt="Dummy ad, edit in sidebar.php"></img></a>
<!-- End Dummy Ad -->

<?php endif; ?>	

</div>

<!-- End Right Sidebar -->


<!-- //// THIS IS WHERE THE 300px AD GOES, NOT WIDGETIZED, ADDED MANUALLY //// -->

<center>
<a href="http://www.dirsnap.com" title="dummy ad, edit in sidebar.php"><img src="https://www.google.com/adsense/static/en_US/images/300x250_img.jpg" alt="dummy ad, edit in sidebar.php" /> </a>
</center>

<!-- //// END 300px AD //// -->

</div>
<!-- end #sidebar -->
